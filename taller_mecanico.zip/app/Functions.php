<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Functions extends Model
{
    
    public function searchbd() {
        return 'LIKE';
    }

}
