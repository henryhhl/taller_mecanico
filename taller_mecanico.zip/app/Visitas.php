<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Visitas extends Model
{
    
    protected $table = 'visitas';

    protected $primaryKey = 'id';

    protected $fillable = [  ];

}
