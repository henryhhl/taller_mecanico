<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Promocion extends Model
{
    
    protected $table = 'promocion';

    protected $primaryKey = 'id';

    protected $fillable = [
        
    ];

}
