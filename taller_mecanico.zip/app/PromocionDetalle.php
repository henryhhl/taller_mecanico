<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PromocionDetalle extends Model
{
    
    protected $table = 'detalle_promocion';

    protected $primaryKey = 'id';

    protected $fillable = [
        
    ];

}
