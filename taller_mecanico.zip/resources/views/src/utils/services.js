

const web = {
    // servidor: 'http://www.tecnoweb.org.bo/grupo10sc/taller_mecanico/servidor/api',          //servidor
    servidor: '',                                                                        //local

    // img_servidor: 'http://www.tecnoweb.org.bo/grupo10sc/taller_mecanico',                  //servidor
    img_servidor: '',                                                                   // local

    // serv_link: '/grupo10sc/taller_mecanico',                                               //servidor
    serv_link: '/taller_mecanico',                                                      //local

    // home: '/grupo10sc/taller_mecanico',                                                    //servidor
    home: '',                                                                           //local
}

export default web;

